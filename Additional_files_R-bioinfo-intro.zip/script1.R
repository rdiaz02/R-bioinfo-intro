x <- 1:10
print(mean(x))
plot(x)
